import express from 'express';
import { randomToken } from './crypto-utils.js';
import fetch from 'node-fetch';
const router = express.Router();

const MODE = process.env.MODE || 'mock';

router.post('/server/create-order', async (req,res)=>{
  const { amount, currency } = req.body;
  if (!amount) return res.status(400).json({ error:'missing amount' });
  if (MODE === 'paypal') {
    return res.status(501).json({ error: 'Enable PayPal helpers in paypal.js and set MODE=paypal' });
  } else {
    const id = 'MOCK-' + randomToken(6).toUpperCase();
    const approve = `${process.env.PAYLINK_SELF_URL || 'http://localhost:4000'}/mock/approve?order=${id}`;
    return res.json({ id, status:'CREATED', links:[{ rel:'approve', href:approve }] });
  }
});

router.post('/server/capture-order', async (req,res)=>{
  const { orderId, payerEmail, plan } = req.body;
  if (!orderId) return res.status(400).json({ error:'missing orderId' });
  if (MODE === 'paypal') {
    return res.status(501).json({ error: 'PayPal capture not implemented in demo' });
  } else {
    const license = 'LIC-' + randomToken(6).toUpperCase();
    const DB = './server/db.json';
    let vault = { clients_encrypted:null, licenses:[], kyc:[], payouts:[] };
    if (fs.existsSync(DB)) vault = JSON.parse(fs.readFileSync(DB,'utf8'));
    vault.licenses = vault.licenses || [];
    vault.licenses.push({ license, plan: plan||'one-time', email:payerEmail||'unknown', active:true, created_at:new Date().toISOString() });
    fs.writeFileSync(DB, JSON.stringify(vault,null,2));
    return res.json({ success:true, license });
  }
});

export default router;
