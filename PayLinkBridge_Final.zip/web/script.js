document.getElementById('req').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  const res = await fetch('/server/issue', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(data) });
  const j = await res.json();
  document.getElementById('out').textContent = JSON.stringify(j,null,2);
});

document.getElementById('kyc').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const res = await fetch('/server/kyc/upload', { method:'POST', body: fd });
  const j = await res.json();
  document.getElementById('kycout').textContent = JSON.stringify(j,null,2);
});
