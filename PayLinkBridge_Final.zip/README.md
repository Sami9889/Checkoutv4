PayLinkBridge Final
===================

This is a full project bundle (demo + PayPal-ready hooks). It is sandbox-safe by default (MODE=mock).
Copy .env.example -> .env and edit values before running.

Quick start:
1. npm install
2. npm start
3. Visit http://localhost:4000

Security notes:
- Do not store real credentials in public repos.
- Use HTTPS and verify webhooks in production.
